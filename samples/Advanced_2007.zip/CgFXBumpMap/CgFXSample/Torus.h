#ifndef __TORUS_H

#define __TORUS_H

#include<windows.h>
#include<gl/gl.h>

GLuint MakeTorus(double r1,double r2,int n1,int n2);

#endif