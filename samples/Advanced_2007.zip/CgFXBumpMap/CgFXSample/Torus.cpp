#ifndef __TORUS_H
#include"Torus.h"
#endif

#include"glext.h" // ���� � ���������� ���������� OpenGL
#include<math.h>

// ��������� �� ������� �� ���������� OpenGL
PFNGLMULTITEXCOORD3DPROC glMultiTexCoord3d = NULL;

const double Pi = 3.1415;

inline void TorusVertex(double r1,double r2,double phi,double psi)
{
	double nx = cos(phi)*cos(psi);
	double ny = sin(psi);
	double nz = sin(phi)*cos(psi);
	float tx = -(float)sin(phi);
	float ty = 0;
	float tz = (float)cos(phi);
	double sx = ny*tz - nz*ty;
	double sy = tx*nz - nx*tz;
	double sz = nx*ty - ny*tx;
	glNormal3d(nx,ny,nz);
	glMultiTexCoord3d(GL_TEXTURE1,tx,ty,tz);
	glMultiTexCoord3d(GL_TEXTURE2,sx,sy,sz);
	glVertex3d(r1*cos(phi) + r2*nx,r2*ny,r1*sin(phi) + r2*nz);
}

GLuint MakeTorus(double r1,double r2,int n1,int n2) {
	if(glMultiTexCoord3d == NULL)
		glMultiTexCoord3d = (PFNGLMULTITEXCOORD3DPROC)wglGetProcAddress("glMultiTexCoord3dARB");
	GLuint list = glGenLists(1);
	glNewList(list,GL_COMPILE);
	glBegin(GL_QUADS);
	for(int i = 0;i<n1;i++) {
		int i2 = (i<n1-1)?(i+1):(0);
		double phi1 = 2*i*Pi/n1;
		double phi2 = 2*i2*Pi/n1;
		for(int j = 0;j<n2;j++) {
			int j2 = (j<n2-1)?(j+1):(0);
			double psi1 = 2*j*Pi/n2;
			double psi2 = 2*j2*Pi/n2;glTexCoord2d(5*i/(double)n1,j/(double)n2);
			glTexCoord2d(5*i/(double)n1,j/(double)n2);
			TorusVertex(r1,r2,phi1,psi1);
			glTexCoord2d(5*i/(double)n1,(j+1)/(double)n2);
			TorusVertex(r1,r2,phi1,psi2);
			glTexCoord2d(5*(i+1)/(double)n1,(j+1)/(double)n2);
			TorusVertex(r1,r2,phi2,psi2);
			glTexCoord2d(5*(i+1)/(double)n1,j/(double)n2);
			TorusVertex(r1,r2,phi2,psi1);
		}
	}
	glEnd();
	glEndList();
	return list;
}
